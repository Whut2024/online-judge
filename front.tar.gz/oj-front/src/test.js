function sleep(seconds) {
  return new Promise((resolve) => setTimeout(resolve, seconds * 1000));
}

async function myFunction() {
  var a = 1;
  while (a < 10) {
    console.log("开始执行");
    await sleep(0.5); // 等待3秒
    console.log("0.5秒后继续执行");
    a++;
  }
}

myFunction();
