<template>
  <div class="about">
    <h1>用户注册页，请自行实现</h1>
  </div>
</template>
