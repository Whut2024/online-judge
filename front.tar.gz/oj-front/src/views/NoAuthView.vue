<template>
  <div class="home">你没权限</div>
</template>

<script lang="ts"></script>
