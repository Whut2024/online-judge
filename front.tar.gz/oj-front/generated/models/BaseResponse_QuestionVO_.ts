/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type {QuestionVO} from './QuestionVO';

export type BaseResponse_QuestionVO_ = {
    code?: number;
    data?: QuestionVO;
    message?: string;
};
