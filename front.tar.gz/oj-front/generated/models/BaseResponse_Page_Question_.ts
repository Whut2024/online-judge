/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Page_Question_ } from './Page_Question_';

export type BaseResponse_Page_Question_ = {
    code?: number;
    data?: Page_Question_;
    message?: string;
};
