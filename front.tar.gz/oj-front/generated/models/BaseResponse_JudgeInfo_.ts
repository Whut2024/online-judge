/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import {JudgeInfo} from "./JudgeInfo";

export type BaseResponse_JudgeInfo_ = {
    code?: number;
    data?: JudgeInfo;
    message?: string;
};
